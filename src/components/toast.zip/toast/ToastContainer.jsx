export const ToastContainer = ({ children }) => {
	return <div className='flex flex-row gap-x-3'>{children}</div>;
};
