import clsx from 'clsx';
export const ToastDescription = ({ text, className }) => {
	return <p className={className}>{text}</p>;
};
